package Food_Shortage;

public interface Birthable {

    String getBirthDate();
}
